$('.nav ul li').click(function () {
    
$(this).addclass("active").sibilings().removeclass('active');
})

const tabBtn = document.querySelectorAll('.nav ul li');
const tab = document.querySelectorAll('.tab');

function tabs(panelindex){
    tab.forEach(function (node) {
      node.style.display = 'none'  
    });
    tab[panelindex].style.display = 'block';
}
tabs(0);


let bio = document.querySelector('.bio');
function bioText(){
    bio.oldtext = bio.innertext;
    bio.innerText = bio.innerText.substring(0,100)+ "....";
    bio.innerHTML += "&nbsp;"+ <span onclick='addlength()' id='see-more-bio'>see 
    more</span>;
}
bioText();
function addlength(){
    bio.innerHTML = bio.oldtext;
    bio.innerHTML += "&nbsp;"+ <span onclick='addlength()' id='see-less-bio'>see 
    less</span>;
}